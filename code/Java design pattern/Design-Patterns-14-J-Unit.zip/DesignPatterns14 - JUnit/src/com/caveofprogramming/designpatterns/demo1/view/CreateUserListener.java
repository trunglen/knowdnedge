package com.caveofprogramming.designpatterns.demo1.view;

public interface CreateUserListener {
	public void userCreated(CreateUserEvent event);
}
