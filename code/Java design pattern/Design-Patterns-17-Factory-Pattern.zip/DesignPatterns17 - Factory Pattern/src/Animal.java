
public interface Animal {
	public void speak();
	public void eat();
}
