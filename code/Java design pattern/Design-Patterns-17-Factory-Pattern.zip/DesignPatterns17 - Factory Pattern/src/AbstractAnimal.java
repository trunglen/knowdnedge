
public class AbstractAnimal {
	public void eat() {
		System.out.println("Chomp chomp chomp");
	}
}
