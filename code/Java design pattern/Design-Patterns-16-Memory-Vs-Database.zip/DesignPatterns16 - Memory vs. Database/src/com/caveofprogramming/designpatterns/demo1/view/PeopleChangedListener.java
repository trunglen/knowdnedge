package com.caveofprogramming.designpatterns.demo1.view;

public interface PeopleChangedListener {
	public void onPeopleChanged();
}
