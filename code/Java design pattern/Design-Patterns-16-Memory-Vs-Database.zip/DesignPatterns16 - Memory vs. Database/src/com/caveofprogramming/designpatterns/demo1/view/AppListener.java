package com.caveofprogramming.designpatterns.demo1.view;

public interface AppListener {
	public void onOpen();
	public void onClose();
}
