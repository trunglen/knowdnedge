package com.caveofprogramming.designpatterns.demo1.view;

public interface SaveListener {
	public void onSave();
}
