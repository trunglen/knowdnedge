package com.caveofprogramming.designpatterns.demo1.model;

import java.util.List;

public class OracleLogDAO implements LogDAO {

	@Override
	public void addEntry(String message) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Log> getEntries(int number) {
		// TODO Auto-generated method stub
		return null;
	}

}
